package solution;

import java.util.Comparator;

public class SortAvgAsc implements Comparator<ActorAverage> {
    public int compare(ActorAverage a, ActorAverage b) {
        Double diffAvg = a.getAverage() - b.getAverage();
        if (diffAvg == 0) {
            return a.getActorName().compareTo(b.getActorName());
        } else {
            if (diffAvg > 0) {
                return 1;
            }
            return -1;
        }
    }
}
