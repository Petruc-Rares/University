package solution;

import actor.ActorsAwards;
import entertainment.Genre;
import entities.NewInput;
import entities.NewMovieData;
import entities.NewSeason;
import entities.NewSerialInputData;
import entities.NewUserData;
import fileio.ActionInputData;
import fileio.ActorInputData;
import fileio.Writer;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import utils.Utils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.stream.Collectors;

public final class Solver {
    /**
     * Input read
     */
    private final NewInput input;
    /**
     * Array returned to main
     */
    private final JSONArray arrayResult;
    /**
     * The class with which we right the array
     */
    private final Writer fileWriter;

    public Solver(final NewInput input, final JSONArray arrayResult, final Writer fileWriter) {
        this.input = input;
        this.arrayResult = arrayResult;
        this.fileWriter = fileWriter;
    }

    public static int getTotalNoViews(List<FilmNumber> films) {
        int noViews = 0;
        for (FilmNumber film : films) {
            noViews += film.getNoFavs();
        }
        return noViews;
    }

    public static int compare(List<FilmNumber> e1, List<FilmNumber> e2) {
        return -(getTotalNoViews(e1) - getTotalNoViews(e2));
    }

    /**
     * Solve the current favorite command and adds value to write to arrayResult
     *
     * @param command is the command received in the test
     * @throws IOException in case of exceptions to reading / writing
     */
    public void solveFavoriteCommand(final ActionInputData command) throws IOException {
        String username = command.getUsername();
        String title = command.getTitle();

        List<NewUserData> users = input.getUsers();
        int commandId = command.getActionId();
        String field = "";
        String message = "";

        for (NewUserData user : users) {
            // check if user exists between the users
            if (user.getUsername().equals(username)) {
                Map<String, Integer> historyViews = user.getHistory();

                // check if the user saw the film so that he can not add
                // it to favorite if he has not seen it
                if (historyViews.containsKey(title)) {
                    ArrayList<String> favMovies = user.getFavoriteMovies();

                    if (favMovies.contains(title)) {
                        message += "error -> " + title + " is already in favourite list";
                    } else {
                        favMovies.add(title);
                        message += "success -> " + title + " was added as favourite";
                    }
                } else {
                    message += "error -> " + title + " is not seen";
                }
            }
        }
        JSONObject test = fileWriter.writeFile(commandId, field, message);
        arrayResult.add(test);
    }

    /**
     * Solve the current view command and adds value to write to arrayResult
     *
     * @param command
     * @throws IOException in case of exceptions to reading / writing
     */
    public void solveViewCommand(final ActionInputData command) throws IOException {
        String username = command.getUsername();
        String title = command.getTitle();

        List<NewUserData> users = input.getUsers();
        int commandId = command.getActionId();
        String field = "";
        String message = "";

        for (NewUserData user : users) {
            // check if user exists between the users
            if (user.getUsername().equals(username)) {
                Map<String, Integer> historyViews = user.getHistory();
                Integer filmViews = historyViews.get(title);

                // check if the user saw the film
                // if seen already, increment filmViews
                if (historyViews.containsKey(title)) {
                    filmViews++;
                } else {
                    // add the film to seen films and set view to 1
                    filmViews = 1;
                }
                historyViews.put(title, filmViews);
                message += "success -> " + title + " was viewed with total views of " + filmViews;
            }
        }

        JSONObject test = fileWriter.writeFile(commandId, field, message);
        arrayResult.add(test);
    }

    public void solveRatingCommand(final ActionInputData command) throws IOException {
        String username = command.getUsername();
        String title = command.getTitle();

        List<NewUserData> users = input.getUsers();
        int commandId = command.getActionId();
        String field = "";
        String message = "";

        for (NewUserData user : users) {
            // check if user exists between the users
            if (user.getUsername().equals(username)) {
                Map<String, Integer> historyViews = user.getHistory();

                String titleSeason = title + " " + command.getSeasonNumber();

                // check if the user saw the title
                // if seen, check if it is already rated
                if ((historyViews.containsKey(title)) || (historyViews.containsKey(titleSeason))) {
                    Map<String, Double> historyRatings = user.getHistoryRatings();

                    // if already rated (film or season)
                    if ((historyRatings.containsKey(title)) ||
                            (historyRatings.containsKey(titleSeason))) {
                        message += "error -> " + title + " has been already rated";
                    } else {
                        // case film
                        if (command.getSeasonNumber() == 0) {
                            // add to seen films
                            historyRatings.put(title, command.getGrade());
                            // in continuare trebuie sa adaugi si la ratingul filmului
                            List<NewMovieData> newMovies = input.getMovies();
                            for (NewMovieData movie : newMovies) {
                                if (movie.getTitle().equals(title)) {
                                    movie.setRating(command.getGrade());
                                }
                            }
                        } // case serial
                        else {
                            historyRatings.put(titleSeason, command.getGrade());
                            List<NewSerialInputData> serials = input.getSerials();
                            for (NewSerialInputData serial : serials) {
                                if (serial.getTitle().equals(title)) {
                                    ArrayList<NewSeason> seasons = serial.getSeasons();
                                    // get the current season (for user count starts from 1)
                                    // this is why we substract 1 to get the desired season
                                    NewSeason gradedSeason =
                                            seasons.get(command.getSeasonNumber() - 1);
                                    gradedSeason.modifiyRating(command.getGrade());
                                    serial.modifyGrade();
                                }
                            }
                        }
                        message += "success -> " + title + " was rated with " + command.getGrade() +
                                " by " + username;
                    }
                } else {
                    message += "error -> " + title + " is not seen";
                }
            }
        }

        JSONObject test = fileWriter.writeFile(commandId, field, message);
        arrayResult.add(test);
    }

    /**
     * Solve the current command
     *
     * @param command
     * @throws IOException in case of exceptions to reading / writing
     */
    public void solveCommand(final ActionInputData command) throws IOException {
        String type = command.getType();

        if (type.equals("favorite")) {
            solveFavoriteCommand(command);
        } else if (type.equals("view")) {
            solveViewCommand(command);
        } else if (type.equals("rating")) {
            solveRatingCommand(command);
        }
    }

    public Integer getNoViews(NewMovieData movie) {
        List<NewUserData> users = input.getUsers();
        String searchedMovieName = movie.getTitle();
        Integer noViews = 0;
        for (NewUserData user : users) {
            Map<String, Integer> userHistory = user.getHistory();
            for (Map.Entry<String, Integer> entry : userHistory.entrySet()) {
                if (entry.getKey().equals(searchedMovieName)) {
                    noViews += entry.getValue();
                    break;
                }
            }
        }
        return noViews;
    }

    public Integer getNoViews(NewSerialInputData movie) {
        List<NewUserData> users = input.getUsers();
        String searchedMovieName = movie.getTitle();
        Integer noViews = 0;
        for (NewUserData user : users) {
            Map<String, Integer> userHistory = user.getHistory();
            for (Map.Entry<String, Integer> entry : userHistory.entrySet()) {
                if (entry.getKey().equals(searchedMovieName)) {
                    noViews += entry.getValue();
                }
            }
        }
        return noViews;
    }

    boolean rightsForPremium(String username) {
        List<NewUserData> users = input.getUsers();
        for (NewUserData user : users) {
            if (user.getUsername().equals(username)) {
                if (user.getSubscriptionType().equals("PREMIUM")) {
                    return true;
                }
            }
        }
        return false;
    }

    public void solveRecommendation(final ActionInputData recommendation) throws IOException {
        String username = recommendation.getUsername();
        List<NewUserData> users = input.getUsers();
        if (recommendation.getType().equals("standard")) {
            for (NewUserData user : users) {
                // if user was found
                if (user.getUsername().equals(username)) {
                    Map<String, Integer> userViews = user.getHistory();
                    List<String> nameFilmsViewed = new ArrayList<>();
                    for (Map.Entry<String, Integer> filmViews : userViews.entrySet()) {
                        nameFilmsViewed.add(filmViews.getKey());
                    }
                    // now we have the films the user saw in nameFilmsViewed
                    List<NewMovieData> moviesDatabase = input.getMovies();
                    boolean movieSeen = true;
                    String nameMovieUnseen = "";

                    for (NewMovieData movie : moviesDatabase) {
                        if (!nameFilmsViewed.contains(movie.getTitle())) {
                            movieSeen = false;
                            nameMovieUnseen = movie.getTitle();
                            break;
                        }
                    }
                    // saw all the movies in the moviesDatabase
                    // so check the serial
                    if (movieSeen == true) {
                        List<NewSerialInputData> serialDatabase = input.getSerials();
                        for (NewSerialInputData serial : serialDatabase) {
                            if (!nameFilmsViewed.contains(serial.getTitle())) {
                                movieSeen = false;
                                nameMovieUnseen = serial.getTitle();
                                break;
                            }
                        }
                        // if still seen al the movies
                        if (movieSeen == true) {
                            int commandId = recommendation.getActionId();
                            String field = "";
                            String message = "StandardRecommendation cannot be applied!";
                            JSONObject test = fileWriter.writeFile(commandId, field, message);
                            arrayResult.add(test);
                            return;
                        }
                    }
                    int commandId = recommendation.getActionId();
                    String field = "";
                    String message = "";
                    message += "StandardRecommendation result: ";
                    message += nameMovieUnseen;
                    JSONObject test = fileWriter.writeFile(commandId, field, message);
                    arrayResult.add(test);
                }
            }
        } else if (recommendation.getType().equals("best_unseen")) {
            for (NewUserData user : users) {
                // if user was found
                if (user.getUsername().equals(username)) {
                    Map<String, Integer> userViews = user.getHistory();
                    List<String> nameFilmsViewed = new ArrayList<>();
                    for (Map.Entry<String, Integer> filmViews : userViews.entrySet()) {
                        nameFilmsViewed.add(filmViews.getKey());
                    }
                    // now we have the films the user saw in nameFilmsViewed
                    List<NewMovieData> moviesDatabase = input.getMovies();
                    boolean movieSeen = true;
                    List<SerialRatingPosition> moviesUnseen = new ArrayList<>();
                    Integer crtPos = 0;

                    for (NewMovieData movie : moviesDatabase) {
                        if (!nameFilmsViewed.contains(movie.getTitle())) {
                            movieSeen = false;
                            moviesUnseen.add(new SerialRatingPosition(movie.getTitle(),
                                    movie.getRating(), crtPos));
                            crtPos++;
                        }
                    }
                    List<NewSerialInputData> serialDatabase = input.getSerials();
                    for (NewSerialInputData serial : serialDatabase) {
                        if (!nameFilmsViewed.contains(serial.getTitle())) {
                            movieSeen = false;
                            moviesUnseen.add(new SerialRatingPosition(serial.getTitle(),
                                    serial.getGrade(), crtPos));
                        }
                    }
                    if (movieSeen == true) {
                        // user saw all movies if enter here
                        int commandId = recommendation.getActionId();
                        String field = "";
                        String message = "BestRatedUnseenRecommendation cannot be applied!";
                        JSONObject test = fileWriter.writeFile(commandId, field, message);
                        arrayResult.add(test);
                        return;
                    }
                    Collections.sort(moviesUnseen, new SortSerialPositionRatPos());
                    int commandId = recommendation.getActionId();
                    String field = "";
                    String message = "BestRatedUnseenRecommendation result: ";
                    message += moviesUnseen.get(0).getNameFilm();
                    JSONObject test = fileWriter.writeFile(commandId, field, message);
                    arrayResult.add(test);
                }
            }
        } else if (recommendation.getType().equals("popular")) {
            if (!rightsForPremium(recommendation.getUsername())) {
                int commandId = recommendation.getActionId();
                String field = "";
                String message = "PopularRecommendation cannot be applied!";
                JSONObject test = fileWriter.writeFile(commandId, field, message);
                arrayResult.add(test);
                return;
            }
            Map<Genre, List<FilmNumber>> genreFilms = new HashMap<>();
            List<NewMovieData> moviesDatabase = input.getMovies();
            for (NewMovieData movie : moviesDatabase) {
                ArrayList<String> genres = movie.getGenres();
                for (int i = 0; i < genres.size(); i++) {
                    Genre genre = Utils.stringToGenre(genres.get(i));
                    if (genreFilms.containsKey(genre)) {
                        List<FilmNumber> filmsGenre = genreFilms.get(genre);
                        FilmNumber newFilmCategory =
                                new FilmNumber(movie.getTitle(), getNoViews(movie));
                        filmsGenre.add(newFilmCategory);
                        // cred ca merge si fara linia urmatoare
                        genreFilms.put(genre, filmsGenre);
                    } else {
                        FilmNumber newFilmCategory =
                                new FilmNumber(movie.getTitle(), getNoViews(movie));
                        List<FilmNumber> filmsGenre = new ArrayList<>();
                        filmsGenre.add(newFilmCategory);
                        genreFilms.put(genre, filmsGenre);
                    }
                }
            }
            List<NewSerialInputData> serialsDatabase = input.getSerials();
            for (NewSerialInputData serial : serialsDatabase) {
                ArrayList<String> genres = serial.getGenres();
                for (int i = 0; i < genres.size(); i++) {
                    Genre genre = Utils.stringToGenre(genres.get(i));
                    if (genreFilms.containsKey(genre)) {
                        List<FilmNumber> filmsGenre = genreFilms.get(genre);
                        FilmNumber newFilmCategory =
                                new FilmNumber(serial.getTitle(), getNoViews(serial));
                        filmsGenre.add(newFilmCategory);
                        // cred ca merge si fara linia urmatoare
                        genreFilms.put(genre, filmsGenre);
                    } else {
                        FilmNumber newFilmCategory =
                                new FilmNumber(serial.getTitle(), getNoViews(serial));
                        List<FilmNumber> filmsGenre = new ArrayList<>();
                        filmsGenre.add(newFilmCategory);
                        genreFilms.put(genre, filmsGenre);
                    }
                }
            }
            // map contains the genres from the films in the database
            // now sort Lists by the number of views in every genre
/*            for (Map.Entry<Genre, List<FilmNumber>> entry : genreFilms.entrySet()) {
                Collections.sort(entry.getValue(), new SortFilmFavnoDesc());
            }*/
            Map<Genre, List<FilmNumber>> sortedMap = genreFilms.entrySet()
                    .stream()
                    .sorted(Map.Entry.comparingByValue(Solver::compare))
                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue,
                            (e1, e2) -> e1, LinkedHashMap::new));

            int noGenres = 0;
            int noMovies = 0;
            String filmRecommandation = "";
            for (Map.Entry<Genre, List<FilmNumber>> entry : sortedMap.entrySet()) {
                List<FilmNumber> currentFilms = entry.getValue();
                noMovies = 0;
                for (FilmNumber currentFilm : currentFilms) {
                    if (!wasMovieSeen(currentFilm.getFilmName(), recommendation.getUsername())) {
                        filmRecommandation = currentFilm.getFilmName();
                        break;
                    }
                    noMovies++;
                }
                if (noMovies < currentFilms.size()) {
                    break;
                }
                noGenres++;
            }
            if (noGenres == sortedMap.size()) {
                int commandId = recommendation.getActionId();
                String field = "";
                String message = "PopularRecommendation cannot be applied!";
                JSONObject test = fileWriter.writeFile(commandId, field, message);
                arrayResult.add(test);
            } else {
                int commandId = recommendation.getActionId();
                String field = "";
                String message = "PopularRecommendation result: ";
                message += filmRecommandation;
                JSONObject test = fileWriter.writeFile(commandId, field, message);
                arrayResult.add(test);
            }
        } else if (recommendation.getType().equals("search")) {
            if (!rightsForPremium(recommendation.getUsername())) {
                int commandId = recommendation.getActionId();
                String field = "";
                String message = "SearchRecommendation cannot be applied!";
                JSONObject test = fileWriter.writeFile(commandId, field, message);
                arrayResult.add(test);
                return;
            }
            List<NewMovieData> movies = input.getMovies();
            List<NewSerialInputData> serials = input.getSerials();
            List<FilmRating> genreFilms = new ArrayList<>();
            for (NewMovieData movie : movies) {
                if (movie.getGenres().contains(recommendation.getGenre())) {
                    genreFilms.add(new FilmRating(movie.getTitle(), movie.getRating()));
                }
            }
            for (NewSerialInputData serial : serials) {
                if (serial.getGenres().contains(recommendation.getGenre())) {
                    genreFilms.add(new FilmRating(serial.getTitle(), serial.getGrade()));
                }
            }
            List<FilmRating> finalFilms = new ArrayList<>();
            for (FilmRating film : genreFilms) {
                if (!wasMovieSeen(film.getNameFilm(), recommendation.getUsername())) {
                    finalFilms.add(film);
                }
            }
            Collections.sort(finalFilms, new SortFilmRatingAsc());
            if (finalFilms.size() != 0) {
                String message = "SearchRecommendation result: ";
                message += finalFilms;
                JSONObject test = fileWriter.writeFile(recommendation.getActionId(), "", message);
                arrayResult.add(test);
            } else {
                String message = "SearchRecommendation cannot be applied!";
                JSONObject test = fileWriter.writeFile(recommendation.getActionId(), "", message);
                arrayResult.add(test);
            }
        } else if (recommendation.getType().equals("favorite")) {
            List<NewMovieData> moviesDatabase = input.getMovies();
            List<SerialRatingPosition> filmsFav = new ArrayList<>();
            Integer crtPos = 0;
            for (NewMovieData movie : moviesDatabase) {
                Integer noFavs = timesFav(movie.getTitle(), recommendation.getUsername());
                // if no added to favorite check next movie
                if (noFavs == 0) {
                    crtPos++;
                    continue;
                } else {
                    SerialRatingPosition filmFavorite =
                            new SerialRatingPosition(movie.getTitle(), (double) noFavs, crtPos);
                    filmsFav.add(filmFavorite);
                }
                crtPos++;
            }

            List<NewSerialInputData> serialsDatabase = input.getSerials();
            for (NewSerialInputData serial : serialsDatabase) {
                Integer noFavs = timesFav(serial.getTitle(), recommendation.getUsername());
                // if no added to favorite check next movie
                if (noFavs == 0) {
                    crtPos++;
                    continue;
                } else {
                    SerialRatingPosition filmFavorite =
                            new SerialRatingPosition(serial.getTitle(), (double) noFavs, crtPos);
                    filmsFav.add(filmFavorite);
                }
                crtPos++;
            }
            // check if the user saw any of the films
            removeSeenFilms(filmsFav, username);

            Collections.sort(filmsFav, new SortSerialPositionRatPos());

            if (filmsFav.size() != 0) {
                int commandId = recommendation.getActionId();
                String field = "";
                String message = "";
                message += "FavoriteRecommendation result: ";

                message += filmsFav.get(0).getNameFilm();
                JSONObject test = fileWriter.writeFile(commandId, field, message);
                arrayResult.add(test);
            } else {
                int commandId = recommendation.getActionId();
                String field = "";
                String message = "FavoriteRecommendation cannot be applied!";
                JSONObject test = fileWriter.writeFile(commandId, field, message);
                arrayResult.add(test);
            }

        }
    }

    public NewUserData isUser(String username) {
        List<NewUserData> users = input.getUsers();
        for (NewUserData user : users) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }

    public void removeSeenFilms(List<SerialRatingPosition> filmsFav, String username) {
        NewUserData user = isUser(username);
        if (user != null) {
            Map<String, Integer> userHistory = user.getHistory();
            ListIterator<SerialRatingPosition> iter = filmsFav.listIterator();
            while (iter.hasNext()) {
                SerialRatingPosition crtFavFilm = iter.next();
                for (Map.Entry<String, Integer> crtFilm : userHistory.entrySet()) {
                    // if movie found in the list of views of the user
                    // remove object from the filmFav
                    if (crtFavFilm.getNameFilm().equals(crtFilm.getKey())) {
                        iter.remove();
                    }
                }
            }
        } else filmsFav = null; // user does not exist, so we don't care about filmsFav
    }

    public Integer timesFav(String movieTitle, String username) {
        List<NewUserData> users = input.getUsers();
        Integer noFavs = 0;
        for (NewUserData user : users) {
            if ((user.getFavoriteMovies().contains(movieTitle)) &&
                    (!user.getUsername().equals(username))) {
                noFavs++;
            }
        }
        return noFavs;
    }

    public boolean wasMovieSeen(String filmName, String username) {
        List<NewUserData> users = input.getUsers();
        for (NewUserData user : users) {
            if (user.getUsername().equals(username)) {
                Map<String, Integer> historyViews = user.getHistory();
                for (Map.Entry<String, Integer> crtFilm : historyViews.entrySet()) {
                    if (crtFilm.getKey().equals(filmName)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * Solve the current action
     *
     * @param action
     * @throws IOException in case of exceptions to reading / writing
     */
    public void solveAction(final ActionInputData action) throws IOException {
        String actionType = action.getActionType();

        if (actionType.equals("command")) {
            solveCommand(action);
        } else if (actionType.equals("query")) {
            solveQuery(action);
        } else if (actionType.equals("recommendation")) {
            solveRecommendation(action);
        }

    }

    public NewMovieData isMovie(String filmName) {
        List<NewMovieData> movies = input.getMovies();
        for (NewMovieData movie : movies) {
            if (movie.getTitle().equals(filmName)) {
                return movie;
            }
        }
        return null;
    }

    public NewSerialInputData isSerial(String filmName) {
        List<NewSerialInputData> serials = input.getSerials();
        for (NewSerialInputData serial : serials) {
            if (serial.getTitle().equals(filmName)) {
                return serial;
            }
        }
        return null;
    }

    /**
     * Solves the query for the actors
     *
     * @param query (current query)
     * @throws IOException in case of exceptions to reading / writing
     */
    public void solveActorsQuery(final ActionInputData query) throws IOException {
        List<ActorInputData> actors = input.getActors();
        final List<String> yearsFilter = query.getFilters().get(0);
        final List<String> genre = query.getFilters().get(1);
        final List<String> words = query.getFilters().get(2);
        final List<String> awards = query.getFilters().get(3);
        if (query.getCriteria().equals("average")) {
            List<ActorAverage> actorsData = new ArrayList<>();
            {
                // for every actor we calculate the rating of the films he played in
                for (ActorInputData actor : actors) {
                    ArrayList<String> actorFilms = actor.getFilmography();
                    Double ratingActor = (double) 0;
                    Double noRatings = (double) 0;
                    for (String film : actorFilms) {
                        NewMovieData movie = isMovie(film);
                        // if movie found
                        if (movie != null) {
                            if (movie.getNoRatings() == 0) {
                                continue;
                            }
                            ratingActor += movie.getRating();
                            noRatings++;
                            continue; // check next film
                        }
                        NewSerialInputData serial = isSerial(film);
                        // if serial found
                        if (serial != null) {
                            if (serial.getNoRatings() == 0) {
                                continue;
                            }
                            ratingActor += serial.getGrade();
                            noRatings++;
                            continue; // check next film
                        }
                        // if not found check next film
                    }
                    // if found some ratings
                    if (noRatings != 0) {
                        ActorAverage actorData = new ActorAverage(actor, ratingActor / noRatings);
                        actorsData.add(actorData);
                    }
                }
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(actorsData, new SortAvgDesc());
            } else {
                Collections.sort(actorsData, new SortAvgAsc());
            }
            int noActors = query.getNumber();
            List<String> finalActors = new ArrayList();
            int i = 0;
            while ((i < noActors) && (i < actorsData.size())) {
                finalActors.add(actorsData.get(i).getActorName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalActors.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("awards")) {
            List<ActorAverage> actorsAwards = new ArrayList<>();
            for (ActorInputData actor : actors) {
                Map<ActorsAwards, Integer> awardsNo = actor.getAwards();

                // in awards we have the filter
                int i;
                for (i = 0; i < awards.size(); i++) {
                    ActorsAwards awardName = Utils.stringToAwards(awards.get(i));
                    // if no awardName in list of awarards of the actors
                    if (!awardsNo.containsKey(awardName)) {
                        break;
                    }
                }
                if ((awards.size() != 0) && (i == awards.size())) {
                } else {
                    continue;
                }
                // if reach here awards were found
                // now let's see how many awards each one has
                int noAwards = 0;
                for (Map.Entry<ActorsAwards, Integer> crtAward : awardsNo.entrySet()) {
                    noAwards += crtAward.getValue();
                }
                actorsAwards.add(new ActorAverage(actor, (double) noAwards));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(actorsAwards, new SortAvgDesc());
            } else {
                Collections.sort(actorsAwards, new SortAvgAsc());
            }
            List<String> finalActors = new ArrayList();
            int i = 0;
            while (i < actorsAwards.size()) {
                finalActors.add(actorsAwards.get(i).getActorName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalActors.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("filter_description")) {
            List<String> finalActors = new ArrayList<>();
            Integer wordsSize = words.size();

            for (ActorInputData actor : actors) {
                String carrerDescription = " ";
                // COMPOSE WORDS
                String newCarrerDescription = actor.getCareerDescription().replaceAll("[-]", " ");
                carrerDescription +=
                        newCarrerDescription.replaceAll("[^a-zA-Z0-9 ]", "").toLowerCase();
                carrerDescription += " ";

                Integer i;
                for (i = 0; i < wordsSize; i++) {
                    String searchedWord = " ";
                    searchedWord += words.get(i);
                    searchedWord += " ";
                    // if it doesn't contain break
                    if (!carrerDescription.contains(searchedWord)) {
                        break;
                    }
                }
                if (i == wordsSize) {
                    finalActors.add(actor.getName());
                }
            }
            if (query.getSortType().equals("asc")) {
                finalActors.sort(Comparator.comparing(String::toString));
            } else {
                finalActors.sort(Comparator.comparing(String::toString).reversed());
            }
            String message = "";
            message += "Query result: ";
            message += finalActors.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);

        }
    }

    public void solveMoviesQuery(final ActionInputData query) throws IOException {
        // isMovie()
        String desiredYear = query.getFilters().get(0).get(0);
        String desiredGenre = query.getFilters().get(1).get(0);
        List<NewUserData> users = input.getUsers();
        Integer favTimes;
        if (query.getCriteria().equals("favorite")) {
            Map<String, Integer> filmFavs = new HashMap<String, Integer>();
            List<FilmNumber> filmsData = new ArrayList<>();
            for (NewUserData user : users) {
                ArrayList<String> favMoviesUser = user.getFavoriteMovies();
                for (String favMovieUser : favMoviesUser) {
                    NewMovieData movie = isMovie(favMovieUser);
                    // if movie found
                    if (!(movie == null)) {
                        // now check if it has the genre and year desired
                        // if desiredYear is specified
                        if (!(desiredYear == null)) {
                            // if year differs, check next movie
                            if (!(movie.getYear() == Integer.parseInt(desiredYear))) {
                                continue;
                            }
                        }
                        if (!(desiredGenre == null)) {
                            // if genres of movie do not contain genre of searched movie
                            // continue
                            if (!(movie.getGenres().contains(desiredGenre))) {
                                continue;
                            }
                        }

                        // increment number of times the film
                        // has been added to favourites
                        if (filmFavs.containsKey(favMovieUser)) {
                            filmFavs.put(favMovieUser, filmFavs.get(favMovieUser) + 1);
                        } else {
                            filmFavs.put(favMovieUser, 1);
                        }
                    } else {
                        continue; // movie not found
                    }
                }
            }
            for (Map.Entry<String, Integer> filmFav : filmFavs.entrySet()) {
                filmsData.add(new FilmNumber(filmFav.getKey(), filmFav.getValue()));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortFilmFavnoDesc());
            } else {
                Collections.sort(filmsData, new SortFilmFavnoAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getFilmName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("ratings")) {
            List<NewMovieData> movies = input.getMovies();
            List<FilmRating> filmsData = new ArrayList<>();
            for (NewMovieData movie : movies) {
                // if no ratings were given check next movie
                if (movie.getNoRatings() == 0) {
                    continue;
                }
                if (!(desiredYear == null)) {
                    // if year differs, check next movie
                    if (!(movie.getYear() == Integer.parseInt(desiredYear))) {
                        continue;
                    }
                }
                if (!(desiredGenre == null)) {
                    // if genres of movie do not contain genre of searched movie
                    // continue
                    if (!(movie.getGenres().contains(desiredGenre))) {
                        continue;
                    }
                }
                filmsData.add(new FilmRating(movie.getTitle(), movie.getRating()));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortFilmRatingDesc());
            } else {
                Collections.sort(filmsData, new SortFilmRatingAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getNameFilm());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("longest")) {
            List<NewMovieData> movies = input.getMovies();
            List<FilmNumber> filmsData = new ArrayList<>();
            for (NewMovieData movie : movies) {
                if (!(desiredYear == null)) {
                    // if year differs, check next movie
                    if (!(movie.getYear() == Integer.parseInt(desiredYear))) {
                        continue;
                    }
                }
                if (!(desiredGenre == null)) {
                    // if genres of movie do not contain genre of searched movie
                    // continue
                    if (!(movie.getGenres().contains(desiredGenre))) {
                        continue;
                    }
                }
                filmsData.add(new FilmNumber(movie.getTitle(), movie.getDuration()));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortFilmFavnoDesc());
            } else {
                Collections.sort(filmsData, new SortFilmFavnoAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getFilmName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("most_viewed")) {
            Map<String, Integer> filmsViewed = new HashMap<String, Integer>();
            List<FilmNumber> filmsData = new ArrayList<>();
            for (NewUserData user : users) {
                Map<String, Integer> viewedMovies = user.getHistory();
                for (Map.Entry<String, Integer> entry : viewedMovies.entrySet()) {
                    NewMovieData movie = isMovie(entry.getKey());
                    // if movie found
                    if (!(movie == null)) {
                        // now check if it has the genre and year desired
                        // if desiredYear is specified
                        if (!(desiredYear == null)) {
                            // if year differs, check next movvie
                            if (!(movie.getYear() == Integer.parseInt(desiredYear))) {
                                continue;
                            }
                        }
                        if (!(desiredGenre == null)) {
                            // if genres of movie do not contain genre of searched movie
                            // continue
                            if (!(movie.getGenres().contains(desiredGenre))) {
                                continue;
                            }
                        }

                        // increment number of times the film
                        // has been added to favourites
                        if (filmsViewed.containsKey(movie.getTitle())) {
                            filmsViewed.put(movie.getTitle(),
                                    filmsViewed.get(movie.getTitle()) + entry.getValue());
                        } else {
                            filmsViewed.put(movie.getTitle(), entry.getValue());
                        }
                    } else {
                        continue; // movie not found
                    }
                }
            }
            for (Map.Entry<String, Integer> filmFav : filmsViewed.entrySet()) {
                filmsData.add(new FilmNumber(filmFav.getKey(), filmFav.getValue()));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortFilmFavnoDesc());
            } else {
                Collections.sort(filmsData, new SortFilmFavnoAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getFilmName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        }
    }

    public void solveShowsQuery(final ActionInputData query) throws IOException {
        // isMovie()
        String desiredYear = query.getFilters().get(0).get(0);
        String desiredGenre = query.getFilters().get(1).get(0);
        List<NewUserData> users = input.getUsers();
        Integer favTimes;
        if (query.getCriteria().equals("favorite")) {
            Map<String, Integer> filmFavs = new HashMap<String, Integer>();
            List<FilmNumber> filmsData = new ArrayList<>();
            for (NewUserData user : users) {
                ArrayList<String> favMoviesUser = user.getFavoriteMovies();
                for (String favMovieUser : favMoviesUser) {
                    NewSerialInputData serial = isSerial(favMovieUser);
                    // if movie found
                    if (!(serial == null)) {
                        // now check if it has the genre and year desired
                        // if desiredYear is specified
                        if (!(desiredYear == null)) {
                            // if year differs, check next movvie
                            if (!(serial.getYear() == Integer.parseInt(desiredYear))) {
                                continue;
                            }
                        }
                        if (!(desiredGenre == null)) {
                            // if genres of movie do not contain genre of searched movie
                            // continue
                            if (!(serial.getGenres().contains(desiredGenre))) {
                                continue;
                            }
                        }

                        // increment number of times the film
                        // has been added to favourites
                        if (filmFavs.containsKey(favMovieUser)) {
                            filmFavs.put(favMovieUser, filmFavs.get(favMovieUser) + 1);
                        } else {
                            filmFavs.put(favMovieUser, 1);
                        }
                    } else {
                        continue; // movie not found
                    }
                }
            }
            for (Map.Entry<String, Integer> filmFav : filmFavs.entrySet()) {
                filmsData.add(new FilmNumber(filmFav.getKey(), filmFav.getValue()));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortFilmFavnoDesc());
            } else {
                Collections.sort(filmsData, new SortFilmFavnoAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getFilmName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("ratings")) {
            List<NewSerialInputData> serials = input.getSerials();
            List<SerialRating> filmsData = new ArrayList<>();
            for (NewSerialInputData serial : serials) {
                // if no ratings were given check next movie
                if (serial.getNoRatings() == 0) {
                    continue;
                }
                if (!(desiredYear == null)) {
                    // if year differs, check next movvie
                    if (!(serial.getYear() == Integer.parseInt(desiredYear))) {
                        continue;
                    }
                }
                if (!(desiredGenre == null)) {
                    // if genres of movie do not contain genre of searched movie
                    // continue
                    if (!(serial.getGenres().contains(desiredGenre))) {
                        continue;
                    }
                }
                filmsData.add(new SerialRating(serial.getTitle(), serial.getGrade()));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortSerialRatingDesc());
            } else {
                Collections.sort(filmsData, new SortSerialRatingAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getNameFilm());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("longest")) {
            List<NewSerialInputData> serials = input.getSerials();
            List<FilmNumber> filmsData = new ArrayList<>();
            for (NewSerialInputData serial : serials) {
                if (!(desiredYear == null)) {
                    // if year differs, check next movvie
                    if (!(serial.getYear() == Integer.parseInt(desiredYear))) {
                        continue;
                    }
                }
                if (!(desiredGenre == null)) {
                    // if genres of movie do not contain genre of searched movie
                    // continue
                    if (!(serial.getGenres().contains(desiredGenre))) {
                        continue;
                    }
                }
                Integer duration = 0;
                for (NewSeason season : serial.getSeasons()) {
                    duration += season.getDuration();
                }
                filmsData.add(new FilmNumber(serial.getTitle(), duration));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortFilmFavnoDesc());
            } else {
                Collections.sort(filmsData, new SortFilmFavnoAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getFilmName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        } else if (query.getCriteria().equals("most_viewed")) {
            Map<String, Integer> filmsViewed = new HashMap<String, Integer>();
            List<FilmNumber> filmsData = new ArrayList<>();
            for (NewUserData user : users) {
                Map<String, Integer> viewedMovies = user.getHistory();
                for (Map.Entry<String, Integer> entry : viewedMovies.entrySet()) {
                    NewSerialInputData serial = isSerial(entry.getKey());
                    // if serial found
                    if (!(serial == null)) {
                        // now check if it has the genre and year desired
                        // if desiredYear is specified
                        if (!(desiredYear == null)) {
                            // if year differs, check next movvie
                            if (!(serial.getYear() == Integer.parseInt(desiredYear))) {
                                continue;
                            }
                        }
                        if (!(desiredGenre == null)) {
                            // if genres of movie do not contain genre of searched movie
                            // continue
                            if (!(serial.getGenres().contains(desiredGenre))) {
                                continue;
                            }
                        }

                        // increment number of times the film
                        // has been added to favourites
                        if (filmsViewed.containsKey(serial.getTitle())) {
                            filmsViewed.put(serial.getTitle(),
                                    filmsViewed.get(serial.getTitle()) + entry.getValue());
                        } else {
                            filmsViewed.put(serial.getTitle(), entry.getValue());
                        }
                    } else {
                        continue; // movie not found
                    }
                }
            }
            for (Map.Entry<String, Integer> filmFav : filmsViewed.entrySet()) {
                filmsData.add(new FilmNumber(filmFav.getKey(), filmFav.getValue()));
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(filmsData, new SortFilmFavnoDesc());
            } else {
                Collections.sort(filmsData, new SortFilmFavnoAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < filmsData.size())) {
                finalFilms.add(filmsData.get(i).getFilmName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        }
    }

    public void solveUsersQuery(final ActionInputData query) throws IOException {

        if (query.getCriteria().equals("num_ratings")) {
            List<NewUserData> users = input.getUsers();
            List<FilmNumber> userNum = new ArrayList<>();
            for (NewUserData user : users) {
                if (user.getHistoryRatings().size() != 0) {
                    userNum.add(
                            new FilmNumber(user.getUsername(), user.getHistoryRatings().size()));
                }
            }
            if (query.getSortType().equals("desc")) {
                Collections.sort(userNum, new SortFilmFavnoDesc());
            } else {
                Collections.sort(userNum, new SortFilmFavnoAsc());
            }
            int noFilms = query.getNumber();
            List<String> finalFilms = new ArrayList();
            int i = 0;
            while ((i < noFilms) && (i < userNum.size())) {
                finalFilms.add(userNum.get(i).getFilmName());
                i++;
            }
            String message = "";
            message += "Query result: ";
            message += finalFilms.toString();
            JSONObject test = fileWriter.writeFile(query.getActionId(), "", message);
            arrayResult.add(test);
        }
    }

    /**
     * Solves the current query in the test
     *
     * @param query (current query)
     * @throws IOException in case of exceptions to reading / writing
     */
    public void solveQuery(final ActionInputData query) throws IOException {
        String type = query.getObjectType();

        if (type.equals("actors")) {
            solveActorsQuery(query);
        } else if (type.equals("movies")) {
            solveMoviesQuery(query);
        } else if (type.equals("shows")) {
            solveShowsQuery(query);
        } else if (type.equals("users")) {
            solveUsersQuery(query);
        }
    }

    /**
     * Solves the actions in the current test
     * no @param
     *
     * @throws IOException in case of exceptions to reading / writing
     */
    public void solve() throws IOException {
        List<ActionInputData> actions = input.getCommands();
        for (ActionInputData action : actions) {
            solveAction(action);
        }
    }

    public NewInput getInput() {
        return input;
    }

    public Writer getFileWriter() {
        return fileWriter;
    }

    public JSONArray getArrayResult() {
        return arrayResult;
    }
}
