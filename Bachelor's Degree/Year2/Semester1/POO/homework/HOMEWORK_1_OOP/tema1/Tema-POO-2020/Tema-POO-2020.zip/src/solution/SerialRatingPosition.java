package solution;

public class SerialRatingPosition extends SerialRating {
    private final Integer position;

    public SerialRatingPosition(String nameFilm, Double rating, Integer position) {
        super(nameFilm, rating);
        this.position = position;
    }

    public Integer getPosition() {
        return position;
    }

    @Override
    public String toString() {
        return "SerialRatingPosition{" +
                "nameFilm = " + this.getNameFilm() + '\'' +
                ",rating = " + this.getRating() + '\'' +
                ",position=" + position +
                '}';
    }
}
