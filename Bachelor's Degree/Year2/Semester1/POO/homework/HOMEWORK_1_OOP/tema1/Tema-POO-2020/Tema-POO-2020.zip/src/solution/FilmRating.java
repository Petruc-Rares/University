package solution;

public class FilmRating {
    private final String nameFilm;
    private final Double rating;

    public FilmRating(String nameFilm, Double rating) {
        this.nameFilm = nameFilm;
        this.rating = rating;
    }

    public String getNameFilm() {
        return nameFilm;
    }

    public Double getRating() {
        return rating;
    }

    @Override
    public String toString() {
        return nameFilm;

    }
}
