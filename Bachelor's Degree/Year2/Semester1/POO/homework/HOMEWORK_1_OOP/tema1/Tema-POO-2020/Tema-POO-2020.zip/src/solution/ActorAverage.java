package solution;

import fileio.ActorInputData;

public class ActorAverage {
    ActorInputData actor;
    Double average;

    public ActorAverage(ActorInputData actor, Double average) {
        this.actor = actor;
        this.average = average;
    }

    @Override
    public String toString() {
        return "ActorAverage{" +
                "actor=" + actor.getName() +
                ", average=" + average +
                '}';
    }

    public Double getAverage() {
        return average;
    }

    public String getActorName() {
        return actor.getName();
    }
}
