package entities;

import fileio.SerialInputData;
import fileio.ShowInput;

import java.util.ArrayList;
import java.util.List;

/**
 * Information about a tv show, retrieved from parsing the input test files
 * <p>
 * DO NOT MODIFY
 */
public final class NewSerialInputData extends ShowInput {
    /**
     * Number of seasons
     */
    private final int numberOfSeasons;
    /**
     * Season list
     */
    private final ArrayList<NewSeason> seasons;
    /**
     * Grade of a serial
     */
    private Double grade;
    /**
     * Number of ratings for the serial (sum of number of ratings for the seasons)
     */
    private Integer noRatings;

    public NewSerialInputData(final String title, final ArrayList<String> cast,
                              final ArrayList<String> genres,
                              final int numberOfSeasons, final ArrayList<NewSeason> seasons,
                              final int year) {
        super(title, year, cast, genres);
        this.numberOfSeasons = numberOfSeasons;
        this.seasons = seasons;
        this.grade = (double) 0;
        this.noRatings = 0;
    }

    public static List<NewSerialInputData> addRating(List<SerialInputData> serials) {
        List<NewSerialInputData> newSerials = new ArrayList<>();
        for (SerialInputData serial : serials) {
            ArrayList<NewSeason> newSeasons = NewSeason.addRating(serial);

            NewSerialInputData newserial =
                    new NewSerialInputData(serial.getTitle(), serial.getCast(), serial.getGenres(),
                            serial.getNumberSeason(), newSeasons, serial.getYear());
            newSerials.add(newserial);
        }
        return newSerials;
    }

    public void modifyGrade() {
        Double sum = (double) 0;
        for (NewSeason season : this.getSeasons()) {
            sum += season.getRating();
        }
        this.grade = sum / this.getNumberOfSeasons();
        // also modify the number of ratings
        this.noRatings++;
    }

    public int getNumberSeason() {
        return numberOfSeasons;
    }

    public ArrayList<NewSeason> getSeasons() {
        return seasons;
    }

    public int getNumberOfSeasons() {
        return numberOfSeasons;
    }

    public Double getGrade() {
        return grade;
    }

    public Integer getNoRatings() {
        return noRatings;
    }

    @Override
    public String toString() {
        return "SerialInputData{" + " title= "
                + super.getTitle() + " " + " year= "
                + super.getYear() + " cast {"
                + super.getCast() + " }\n" + " genres {"
                + super.getGenres() + " }\n "
                + " numberSeason= " + numberOfSeasons
                + ", seasons=" + seasons + "\n\n" + '}';
    }
}
