package entities;

import fileio.MovieInputData;

import java.util.ArrayList;
import java.util.List;

public class NewMovieData {

    private final String title;
    private final ArrayList<String> cast;
    private final ArrayList<String> genres;
    private final int year;
    /**
     * Duration in minutes of a season
     */
    private final int duration;
    private Double rating;
    private Integer noRatings;

    public NewMovieData(final String title, final ArrayList<String> cast,
                        final ArrayList<String> genres, final int year,
                        final int duration) {
        this.title = title;
        this.cast = cast;
        this.genres = genres;
        this.year = year;
        this.duration = duration;
        this.rating = Double.valueOf(0);
        this.noRatings = 0;
    }

    static public List<NewMovieData> addRatingField(List<MovieInputData> movies) {
        List<NewMovieData> movies2 = new ArrayList<>();
        for (MovieInputData movie : movies) {
            NewMovieData movieAux = new NewMovieData(movie.getTitle(), movie.getCast(),
                    movie.getGenres(), movie.getYear(), movie.getDuration());
            movies2.add(movieAux);
        }
        return movies2;
    }

    @Override
    public String toString() {
        return "MovieInputData{" + "title= "
                + this.getTitle() + "year= "
                + this.getYear() + "duration= "
                + duration + "cast {"
                + this.getCast() + " }\n"
                + "genres {" + this.getGenres() + " }\n ";
    }

    public String getTitle() {
        return title;
    }

    public ArrayList<String> getCast() {
        return cast;
    }

    public ArrayList<String> getGenres() {
        return genres;
    }

    public int getYear() {
        return year;
    }

    public Double getRating() {
        return rating;
    }

    public void setRating(Double ratingByUser) {

        this.rating *= this.noRatings;

        this.rating += ratingByUser;
        // change the number of current ratings
        this.noRatings++;

        this.rating /= this.noRatings;
    }

    public Integer getNoRatings() {
        return noRatings;
    }

    public int getDuration() {
        return duration;
    }
}
