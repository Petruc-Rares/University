package solution;

public enum ActionTypes {
    COMMAND, QUERY
}
