package solution;

import java.util.Comparator;


public class SortAvgDesc implements Comparator<ActorAverage> {
    public int compare(ActorAverage a, ActorAverage b) {
        Double diffAvg = b.getAverage() - a.getAverage();
        if (diffAvg == 0) {
            return b.getActorName().compareTo(a.getActorName());
        } else {
            if (diffAvg > 0) {
                return 1;
            }
            return -1;
        }
    }
}
