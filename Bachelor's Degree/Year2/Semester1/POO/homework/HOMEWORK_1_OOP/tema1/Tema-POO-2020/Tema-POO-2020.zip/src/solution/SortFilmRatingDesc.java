package solution;

import java.util.Comparator;

public class SortFilmRatingDesc implements Comparator<FilmRating> {
    public int compare(FilmRating a, FilmRating b) {
        Double diffAvg = b.getRating() - a.getRating();
        if (diffAvg == 0) {
            return b.getNameFilm().compareTo(a.getNameFilm());
        } else {
            if (diffAvg > 0) {
                return 1;
            }
            return -1;
        }
    }

}
