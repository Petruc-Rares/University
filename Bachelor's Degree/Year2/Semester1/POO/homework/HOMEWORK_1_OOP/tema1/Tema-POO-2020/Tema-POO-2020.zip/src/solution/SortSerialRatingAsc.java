package solution;

import java.util.Comparator;

public class SortSerialRatingAsc implements Comparator<SerialRating> {
    public int compare(SerialRating a, SerialRating b) {
        Double diffAvg = a.getRating() - b.getRating();
        if (diffAvg == 0) {
            return a.getNameFilm().compareTo(b.getNameFilm());
        } else {
            if (diffAvg > 0) {
                return 1;
            }
            return -1;
        }
    }
}
