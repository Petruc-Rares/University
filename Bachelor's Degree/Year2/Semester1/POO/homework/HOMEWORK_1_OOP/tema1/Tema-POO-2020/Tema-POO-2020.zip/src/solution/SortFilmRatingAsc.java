package solution;

import java.util.Comparator;

public class SortFilmRatingAsc implements Comparator<FilmRating> {
    public int compare(FilmRating a, FilmRating b) {
        Double diffAvg = a.getRating() - b.getRating();
        if (diffAvg == 0) {
            return a.getNameFilm().compareTo(b.getNameFilm());
        } else {
            if (diffAvg > 0) {
                return 1;
            }
            return -1;
        }
    }
}
