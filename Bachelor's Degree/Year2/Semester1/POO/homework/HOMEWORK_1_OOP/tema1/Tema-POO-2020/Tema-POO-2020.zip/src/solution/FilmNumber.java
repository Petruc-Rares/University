package solution;

public class FilmNumber {
    String filmName;
    Integer noFavs;

    public FilmNumber(String filmName, Integer noFavs) {
        this.filmName = filmName;
        this.noFavs = noFavs;
    }


    public Integer getNoFavs() {
        return noFavs;
    }

    public String getFilmName() {
        return filmName;
    }

    @Override
    public String toString() {
        return "FilmNumber{" +
                "filmName='" + filmName + '\'' +
                ", noViews=" + noFavs +
                '}';
    }
}
