package solution;

import java.util.Comparator;
import java.util.List;

public class SortByTotalNoViews implements Comparator<List<FilmNumber>> {
    public int compare(List<FilmNumber> a, List<FilmNumber> b) {
        Integer diffAvg = b.size() - a.size();
        return diffAvg;
    }
}
