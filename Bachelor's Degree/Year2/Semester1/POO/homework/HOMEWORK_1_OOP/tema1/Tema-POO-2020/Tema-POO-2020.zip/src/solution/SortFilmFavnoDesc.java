package solution;

import java.util.Comparator;

public class SortFilmFavnoDesc implements Comparator<FilmNumber> {
    public int compare(FilmNumber a, FilmNumber b) {
        Integer diffAvg = b.getNoFavs() - a.getNoFavs();
        if (diffAvg == 0) {
            return b.getFilmName().compareTo(a.getFilmName());
        } else {
            return diffAvg;
        }
    }
}
