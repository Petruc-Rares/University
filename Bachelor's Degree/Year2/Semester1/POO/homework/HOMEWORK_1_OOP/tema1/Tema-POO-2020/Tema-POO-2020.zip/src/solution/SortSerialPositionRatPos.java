package solution;

import java.util.Comparator;

public class SortSerialPositionRatPos implements Comparator<SerialRatingPosition> {
    public int compare(SerialRatingPosition a, SerialRatingPosition b) {
        Double diffAvg = b.getRating() - a.getRating();
        if (diffAvg == 0) {
            // we want to keep it sorted by the position in the database
            return a.getPosition().compareTo(b.getPosition());
        } else {
            if (diffAvg > 0) {
                return 1;
            }
            return -1;
        }
    }
}
