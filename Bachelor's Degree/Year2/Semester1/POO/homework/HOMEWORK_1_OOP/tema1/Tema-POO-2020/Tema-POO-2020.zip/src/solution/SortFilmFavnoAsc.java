package solution;

import java.util.Comparator;

public class SortFilmFavnoAsc implements Comparator<FilmNumber> {
    public int compare(FilmNumber a, FilmNumber b) {
        Integer diffAvg = a.getNoFavs() - b.getNoFavs();
        if (diffAvg == 0) {
            return a.getFilmName().compareTo(b.getFilmName());
        } else {
            return diffAvg;
        }
    }
}
