package solution;

public class SerialRating {
    private final String nameFilm;
    private final Double rating;

    public SerialRating(String nameFilm, Double rating) {
        this.nameFilm = nameFilm;
        this.rating = rating;
    }

    public String getNameFilm() {
        return nameFilm;
    }

    public Double getRating() {
        return rating;
    }

    @Override
    public String toString() {
        return "FilmRating{" +
                "nameFilm='" + nameFilm + '\'' +
                ", rating=" + rating +
                '}';
    }
}
