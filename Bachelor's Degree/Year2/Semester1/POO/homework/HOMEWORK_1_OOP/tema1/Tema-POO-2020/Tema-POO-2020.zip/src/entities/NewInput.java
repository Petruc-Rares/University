package entities;

import fileio.ActionInputData;
import fileio.ActorInputData;

import java.util.List;

/**
 * The class contains information about input
 * <p>
 * DO NOT MODIFY
 */
public final class NewInput {
    /**
     * List of actors
     */
    private final List<ActorInputData> actorsData;
    /**
     * List of users
     */
    private final List<NewUserData> usersData;
    /**
     * List of commands
     */
    private final List<ActionInputData> commandsData;
    /**
     * List of movies
     */
    private final List<NewMovieData> moviesData;
    /**
     * List of serials aka tv shows
     */
    private final List<NewSerialInputData> serialsData;

    public NewInput() {
        this.actorsData = null;
        this.usersData = null;
        this.commandsData = null;
        this.moviesData = null;
        this.serialsData = null;
    }

    public NewInput(final List<ActorInputData> actors, final List<NewUserData> users,
                    final List<ActionInputData> commands,
                    final List<NewMovieData> movies,
                    final List<NewSerialInputData> serials) {
        this.actorsData = actors;
        this.usersData = users;
        this.commandsData = commands;
        this.moviesData = movies;
        this.serialsData = serials;
    }

    public List<ActorInputData> getActors() {
        return actorsData;
    }

    public List<NewUserData> getUsers() {
        return usersData;
    }

    public List<ActionInputData> getCommands() {
        return commandsData;
    }

    public List<NewMovieData> getMovies() {
        return moviesData;
    }

    public List<NewSerialInputData> getSerials() {
        return serialsData;
    }
}
