import java.io.*;
import java.util.*;

class Poduri{

    private static class SeaGrid {
        private Integer N;
        // used for further calculations
        private Integer extendedN;
        private Integer M;
        private Integer extendedM;
        private Integer idStart;
        private Integer totalSize;
        private Integer idxRowStart;
        private Integer idxColumnStart;
        //private String[] adj;
        private char[][] adj;

        public static final int NMAX = (int) 2050; // 2050*2050

        SeaGrid(Integer N, Integer M) {
            this.N = N;
            this.M = M;
            this.extendedN = N + 2;
            this.extendedM = M + 2;
            this.totalSize = N*M + 2*M + 2*N + 4;
            // number of total vertexes covers the margins (the land)
            // outside the bridges
            //bridgesGraph = new Utils.Graph(N*M + 2*M + 2*N + 4);
            //adj = new String[extendedN];
            adj = new char[N][M];
        }

        public Integer getTotalSize() {
            return totalSize;
        }

        public void setTotalSize(Integer totalSize) {
            this.totalSize = totalSize;
        }


        public char[][] getAdj() {
            return adj;
        }

        public void setAdj(char[][] adj) {
            this.adj = adj;
        }

        /*
                public String[] getAdj() {
                    return adj;
                }

                public void setAdj(String[] adj) {
                    this.adj = adj;
                }
        */
        public void setIdxRowStart(Integer idxRowStart) {
            this.idxRowStart = idxRowStart;
        }

        public Integer getIdxRowStart() {
            return idxRowStart;
        }

        public Integer getIdxColumnStart() {
            return idxColumnStart;
        }

        public void setIdxColumnStart(Integer idxColumnStart) {
            this.idxColumnStart = idxColumnStart;
        }

        public Integer getExtendedN() {
            return extendedN;
        }

        public Integer getExtendedM() {
            return extendedM;
        }

        public Integer getCorrespondingIdX(Integer RowIdx, Integer ColumnIdx) {
            return RowIdx * extendedM + ColumnIdx;
        }


        public Integer getIdStart() {
            return idStart;
        }



        public void setIdStart(Integer idStart) {
            this.idStart = idStart;
        }

        public Integer getN() {
            return N;
        }

        public void setN(Integer n) {
            N = n;
        }

        public Integer getM() {
            return M;
        }

        public void setM(Integer m) {
            M = m;
        }


        @Override
        public String toString() {
            return "SeaGrid{" +
                    "N=" + N +
                    ", M=" + M +
                    ", idStart=" + idStart +
                    '}';
        }
    }

    static class IntPair {
        int x;
        int y;
        int id;

        IntPair(int x, int y, int id) {
            this.x = x;
            this.y = y;
            this.id = id;
        }
    }


    static Integer getMinimumDistances(SeaGrid seaGrid) {
        Integer totalSize = seaGrid.getTotalSize();
        Integer distances[] = new Integer[totalSize];
        Boolean visited[] = new Boolean[totalSize];
        Queue<IntPair> queue = new LinkedList<>();

        Integer src = seaGrid.idStart;
        distances[src] = 0;
        queue.add(new IntPair(seaGrid.getIdxColumnStart(), seaGrid.getIdxRowStart(), src));

        Integer marginDown = seaGrid.N - 1;
        Integer marginRight = seaGrid.M - 1;

        while(!queue.isEmpty()) {
            IntPair crtElem = queue.remove();
            Integer crtRow = crtElem.y;
            Integer crtColumn = crtElem.x;

            Integer crtId = crtElem.id;
            if (visited[crtId] == null) {
                visited[crtId] = true;

                char crtChar = seaGrid.adj[crtRow][crtColumn];
                if (crtChar == '.') continue;
                else if (crtChar == 'V') {
                    if ((crtRow == 0) || (crtRow.equals(marginDown))) {
                        return distances[crtId] + 1;
                    }
                    Integer newDistance = distances[crtId] + 1;
                    queue.add(new IntPair(crtColumn, crtRow - 1, crtId - seaGrid.extendedM));
                    queue.add(new IntPair(crtColumn, crtRow + 1, crtId + seaGrid.extendedM));

                    distances[crtId - seaGrid.extendedM] = newDistance;
                    distances[crtId + seaGrid.extendedM] = newDistance;
                } else if (crtChar == 'O') {
                    if ((crtColumn == 0) || (crtColumn.equals(marginRight))) {
                        return distances[crtId] + 1;
                    }
                    Integer newDistance = distances[crtId] + 1;
                    queue.add(new IntPair(crtColumn - 1, crtRow, crtId - 1));
                    queue.add(new IntPair(crtColumn + 1, crtRow, crtId + 1));

                    distances[crtId - 1] = newDistance;
                    distances[crtId + 1] = newDistance;
                } else if (crtChar == 'D') {
                    if ((crtColumn == 0) || (crtColumn.equals(marginRight))
                    || (crtRow == 0) || (crtRow.equals(marginDown))) {
                        return distances[crtId] + 1;
                    }
                    Integer newDistance = distances[crtId] + 1;
                    queue.add(new IntPair(crtColumn, crtRow - 1, crtId - seaGrid.extendedM));
                    queue.add(new IntPair(crtColumn, crtRow + 1, crtId + seaGrid.extendedM));
                    queue.add(new IntPair(crtColumn - 1, crtRow, crtId - 1));
                    queue.add(new IntPair(crtColumn + 1, crtRow, crtId + 1));

                    distances[crtId - seaGrid.extendedM] = newDistance;
                    distances[crtId + seaGrid.extendedM] = newDistance;
                    distances[crtId - 1] = newDistance;
                    distances[crtId + 1] = newDistance;
                }
            }
        }

        return -1;
    }

    public static SeaGrid lastCreate() {
        MyScanner scanner = new MyScanner("poduri.in");

        Integer N = scanner.nextInt();
        Integer M = scanner.nextInt();

        SeaGrid seaGrid = new SeaGrid(N, M);

        Integer startPosY = scanner.nextInt();
        Integer startPosX = scanner.nextInt();

        seaGrid.setIdxRowStart(startPosY - 1);
        seaGrid.setIdxColumnStart(startPosX - 1);

        seaGrid.setIdStart(seaGrid.
                getCorrespondingIdX(startPosY - 1, startPosX - 1));

        String line;

        char[][] seaGridRepr = seaGrid.getAdj();
        // "_" represents land
        //seaGridRepr[0] = String.fil
        //for (int i = 0; i < seaGrid.extendedM +1 ; i++)
        //    seaGridRepr[0].charAt(i) = 0;
        //while(scanner.nextLine() != null)
        int idxRow = 0;
        while((line  = scanner.nextLine()) != null) {
            seaGridRepr[idxRow++] =  line.toCharArray();
        }
        //seaGridRepr[seaGrid.N + 1] = ("_".repeat(seaGrid.M + 1));

/*
        for (int i = 0; i < seaGrid.N; i++) {
            for (int j = 0; j < seaGrid.M; j++) {
                System.out.print(seaGridRepr[i][j]);
            }
            System.out.println();
        }
*/
        return seaGrid;
    }

    public static void main(String[] args) throws IOException {
        long startTime = System.nanoTime();

       // SeaGrid seaGrid = createSeaGrid();
        SeaGrid seaGrid = lastCreate();

        Integer minimumDistance = getMinimumDistances(seaGrid);
        //System.out.println(minimumDistance);

        /*char test[][] = new char[10][10];
        test[1][2] = "daraianaba".toCharArray();


        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 10; j++) {
                System.out.print(test[i][j]);
            }
            System.out.println();
        }*/


        long elapsedTime = System.nanoTime() - startTime;
        try {
            FileWriter myWriter = new FileWriter("poduri.out");
            myWriter.write(minimumDistance + "");
            //myWriter.write(1 + "");
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        System.out.println("Total execution time to create 1000K objects in Java in s: "
                + elapsedTime/1e9);
    }
}