import java.io.*;
import java.util.StringTokenizer;

class SumTest {

	public static void main(String[] args) {
		MyScanner sc = new MyScanner("stdin");
		int sum = 0;
		int N = sc.nextInt();
		for (int i = 0; i < N; i++) {
			sum += sc.nextInt();
		}
		System.out.println(sum);
	}

}

// Folositi clasa aceasta pentru o citire mai rapida
// sursa: http://codeforces.com/blog/entry/7018
class MyScanner {
	BufferedReader br;
	StringTokenizer st;

	public MyScanner(String nameFile) {
		try {
			br = new BufferedReader(new InputStreamReader(new FileInputStream(new File(nameFile))));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	String next() {
		while (st == null || !st.hasMoreElements()) {
			try {
				st = new StringTokenizer(br.readLine());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return st.nextToken();
	}

	int nextInt() {
		return Integer.parseInt(next());
	}

	long nextLong() {
		return Long.parseLong(next());
	}

	double nextDouble() {
		return Double.parseDouble(next());
	}

	String nextLine(){
		String str = "";
		try {
			str = br.readLine();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return str;
	}
}