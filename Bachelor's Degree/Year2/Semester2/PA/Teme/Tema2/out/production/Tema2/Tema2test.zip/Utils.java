import java.util.*;

public class Utils {
    /*
    static class Graph {
        /*Integer N;

        private Map<Integer, List<Integer> > map = new HashMap<>();

        Graph(Integer N) {
            this.N = N;
        }

        // This function adds a new vertex to the graph
        public void addVertex(Integer s)
        {
            map.put(s, new LinkedList<Integer>());
        }

        // This function adds the edge
        // between source to destination
        public void addEdge(Integer source,
                            Integer destination) {

            map.get(source).add(destination);
        }

        public List<Integer> getAdjList(Integer id) {
            return map.get(id);
        } 
        // number of valid vertexes

        Integer N;

        public static final int NMAX = (int) 4202500; // 2050*2050
        ArrayList<Integer>[] adj = new ArrayList[NMAX];

        Graph(Integer N) {
            this.N = N;
        }

        void addVertex(Integer id) {
            adj[id] = new ArrayList<>();
        }

        void addEdge(Integer id1, Integer id2) {
            adj[id1].add(id2);
        }

        List<Integer> getAdjVertices(Integer id) {
            return adj[id];
        }

    } */
    static Integer minIntegerValue(Integer a, Integer b) {
        return a < b ? a : b;
    }
}
