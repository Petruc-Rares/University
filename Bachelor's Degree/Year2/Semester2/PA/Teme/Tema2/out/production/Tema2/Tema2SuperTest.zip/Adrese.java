import javax.xml.transform.Result;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Adrese {

    private static class GraphPlatform {
        private HashMap<PlatformInstance, List<PlatformInstance>> relationshipPlatform;
        private Integer noInstances;

        public GraphPlatform() {
            this.relationshipPlatform = new HashMap<>();
        }

        public void addVertex(PlatformInstance vertex) {
            relationshipPlatform.put(vertex, new ArrayList<>());
        }

        public boolean hasVertex(PlatformInstance key) {
            return relationshipPlatform.containsKey(key);
        }

        public void addEdge(PlatformInstance s, PlatformInstance d) {
            relationshipPlatform.get(s).add(d);
            relationshipPlatform.get(d).add(s);
           // relationshipPlatform.put(s,l);
        }

        public Integer getNoInstances() {
            return noInstances;
        }

        public void setNoInstances(Integer noInstances) {
            this.noInstances = noInstances;
        }

        public HashMap<PlatformInstance, List<PlatformInstance>> getRelationshipPlatform() {
            return relationshipPlatform;
        }

        public void setRelationshipPlatform(HashMap<PlatformInstance, List<PlatformInstance>> relationshipPlatform) {
            this.relationshipPlatform = relationshipPlatform;
        }
    }

    private static class PlatformInstance {
        String name;
        int type;  //  0 - userName, 1 - address
        int id; // this one will be used just to differentiate between
                // people holding the same userName, but which might be different


        public PlatformInstance(String name, int type) {
            this.name = name;
            this.type = type;
        }

        public PlatformInstance(String name, int type, int id) {
            this.name = name;
            this.type = type;
            this.id = id;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (o == null || getClass() != o.getClass()) return false;
            PlatformInstance that = (PlatformInstance) o;
            if ((type == 1) && (that.type == 1)) {
                return name.equals(that.name);
            }
            return type == that.type && id == that.id && Objects.equals(name, that.name);
        }

        @Override
        public int hashCode() {
            if (type == 0) {
                return Objects.hash(id);
            } else if (type == 1) {
                return Objects.hash(name);
            }
            return 0;
        }

        @Override
        public String toString() {
            return "PlatformInstance{" +
                    "name='" + name + '\'' +
                    ", type=" + type +
                    ", id=" + id +
                    '}';
        }
    }

    public static GraphPlatform lastCreate() {
        MyScanner scanner = new MyScanner("adrese.in");
        //HashMap<String, List<String>> userToAddressees;
        GraphPlatform graphPlatform = new GraphPlatform();
        HashMap<PlatformInstance, List<PlatformInstance>> relationshipPlatform = graphPlatform.getRelationshipPlatform();


        Integer N = scanner.nextInt();

       // System.out.println("Sunt " + N + " posibile persoane");

        String line;
        HashMap<PlatformInstance, Integer> emails = new HashMap<>();

        int id = 0;
        for (int crtUser = 0; crtUser < N; crtUser++){
            String infoUser[] = scanner.nextLine().split(" ");

            //System.out.println("Persoana cu numele " + infoUser[0] + " are " +infoUser[1] + " adrese");
            //System.out.println(infoUser[1]);

            String nameUser = infoUser[0];
            PlatformInstance user = new PlatformInstance(nameUser, 0, id);
            id++;
            graphPlatform.addVertex(user);


            Integer NoAddresses = Integer.parseInt(infoUser[1]);

            // aici citim adresele corespunzatoare unui user
            for (int i = 0; i < NoAddresses; i++) {
                PlatformInstance newMail = new PlatformInstance(scanner.next(), 1, id);
                if (!(graphPlatform.hasVertex(newMail))) {
                    graphPlatform.addVertex(newMail);

                    /*System.out.println("in if inainte de put");
                    System.out.println(emails);*/
                    emails.put(newMail, id);
                    /*System.out.println("in if dupa put");
                    System.out.println(emails);*/
                    id++;
                } else {
                    newMail.id = emails.get(newMail);
                }
                graphPlatform.addEdge(user, newMail);
            }
            //id++;
        }


/*        for (PlatformInstance name: relationshipPlatform.keySet()) {
            String key = name.toString();
            String value = relationshipPlatform.get(name).toString();
            System.out.println(key + " " + value);
        }
*/
        graphPlatform.setNoInstances(id);
        return graphPlatform;
    }

    public static Integer time = 0;
    private static Boolean visited[];
    private static char colors[];

    static class ResultFormat {
        String userName;
        Integer noMails;
        PriorityQueue<String> mails;


        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public Integer getNoMails() {
            return noMails;
        }

        public void setNoMails(Integer noMails) {
            this.noMails = noMails;
        }

        public PriorityQueue<String> getMails() {
            return mails;
        }

        public void setMails(PriorityQueue<String> mails) {
            this.mails = mails;
        }

        @Override
        public String toString() {
            return "ResultFormat{" +
                    "userName='" + userName + '\'' +
                    ", noMails=" + noMails +
                    ", mails=" + mails +
                    '}';
        }
    }

    public static ResultFormat bfs_util(HashMap<PlatformInstance, List<PlatformInstance>> relationShipsPlatform, PlatformInstance platformInstance) {

        PriorityQueue<String> emails = new PriorityQueue<>();
        String lowestName = BIGGESTNAME;

        Queue<PlatformInstance> queue = new LinkedList<>();
        queue.add(platformInstance);

        //System.out.println(platformInstance);

        ResultFormat result = new ResultFormat();
        int no = 0;
        while(!(queue.isEmpty())) {
            PlatformInstance crtElem = queue.remove();

            if(crtElem.type == 0) {
                // case username
                if (lowestName.compareTo(crtElem.name) > 0) {
                    lowestName = crtElem.name;
                }
            } else if (crtElem.type == 1) {
                emails.add(crtElem.name);
                no++;
                //result.getMails().add(crtElem.name);
            }

            List<PlatformInstance> succs = relationShipsPlatform.get(crtElem);
            for (PlatformInstance succ : succs) {
                if (visited[succ.id] == null) {
                    //System.out.println(succ);
                    visited[succ.id] = true;
                    queue.add(succ);
                }
            }
        }

        result.setUserName(lowestName);
        result.setMails(emails);
        result.setNoMails(no);

       // System.out.println(result);

/*        while (emails.size() != 0) {
            System.out.println(emails.remove());
        }*/
        return result;
    }

    static class ComparatorResult implements Comparator<ResultFormat> {
        @Override
        public int compare(ResultFormat a, ResultFormat b) {
            int diff = a.noMails - b.noMails;
            if (diff != 0) return diff;

            return a.userName.compareTo(b.userName);
        }
    }

    public static Integer bfs(GraphPlatform graphPlatform) {
        //System.out.println("Exista " + graphPlatform.noInstances + " instante");
        visited = new Boolean[graphPlatform.noInstances];
        //colors = new char[graphPlatform.noInstances];

        List<ResultFormat> results = new ArrayList<>();

        Integer counts = 0;
        HashMap<PlatformInstance, List<PlatformInstance>> relationshipPlatform = graphPlatform.getRelationshipPlatform();
        for (PlatformInstance platformInstance: relationshipPlatform.keySet()) {
            if (visited[platformInstance.id] == null) {
                visited[platformInstance.id] = true;
                ResultFormat result= bfs_util(relationshipPlatform, platformInstance);
                results.add(result);
                counts++;
            }
        }

        Collections.sort(results, new ComparatorResult());

        try {
            FileWriter myWriter = new FileWriter("adrese.out");
            myWriter.write(counts + "\n");

            for(ResultFormat result: results) {
                myWriter.write(result.userName + " " + result.noMails+"\n");
                PriorityQueue<String> mails = result.mails;
                while (mails.size() != 0) {
                    myWriter.write(mails.remove() + "\n");
                }
            }

            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        System.out.println(counts);
        return 1;
    }

    public static final String BIGGESTNAME ="ZZZZZZZZZZZZZZZZZZZZ";

    public static void main(String[] args) {
       // long startTime = System.nanoTime();
        GraphPlatform graphPlatform = lastCreate();

        bfs(graphPlatform);
     //   long elapsedTime = System.nanoTime() - startTime;
     //   System.out.println("Total execution time to create 1000K objects in Java in s: "
     //           + elapsedTime/1e9);

       // System.out.println(BIGGESTNAME.compareTo("JFAEFA"));
        //PriorityQueue<String> sortedStrings = new PriorityQueue();
        /*sortedStrings.add("zuhu");
        sortedStrings.add("duhu");
        sortedStrings.add("ruhu");
        sortedStrings.add("aluhu");
        while(!sortedStrings.isEmpty()) {
            System.out.println(sortedStrings.poll());
        }*/
    }

}
