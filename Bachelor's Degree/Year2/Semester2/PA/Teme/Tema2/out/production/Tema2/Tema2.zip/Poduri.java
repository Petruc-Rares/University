import jdk.swing.interop.SwingInterOpUtils;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

class Poduri{

    private static class SeaGrid {
        private Integer N;
        // used for further calculations
        private Integer extendedN;
        private Integer M;
        private Integer extendedM;
        private Integer idStart;
        private Integer totalSize;
        private Integer idxRowStart;
        private Integer idxColumnStart;
        private String[] adj;

        public static final int NMAX = (int) 2050; // 2050*2050

        SeaGrid(Integer N, Integer M) {
            this.N = N;
            this.M = M;
            this.extendedN = N + 2;
            this.extendedM = M + 2;
            this.totalSize = N*M + 2*M + 2*N + 4;
            // number of total vertexes covers the margins (the land)
            // outside the bridges
            //bridgesGraph = new Utils.Graph(N*M + 2*M + 2*N + 4);
            adj = new String[extendedN];
        }

        public Integer getTotalSize() {
            return totalSize;
        }

        public void setTotalSize(Integer totalSize) {
            this.totalSize = totalSize;
        }

        public String[] getAdj() {
            return adj;
        }

        public void setAdj(String[] adj) {
            this.adj = adj;
        }

        public void setIdxRowStart(Integer idxRowStart) {
            this.idxRowStart = idxRowStart;
        }

        public Integer getIdxRowStart() {
            return idxRowStart;
        }

        public Integer getIdxColumnStart() {
            return idxColumnStart;
        }

        public void setIdxColumnStart(Integer idxColumnStart) {
            this.idxColumnStart = idxColumnStart;
        }

        public Integer getExtendedN() {
            return extendedN;
        }

        public Integer getExtendedM() {
            return extendedM;
        }

        public Integer getCorrespondingIdX(Integer RowIdx, Integer ColumnIdx) {
            return RowIdx * extendedM + ColumnIdx;
        }


        public Integer getIdStart() {
            return idStart;
        }



        public void setIdStart(Integer idStart) {
            this.idStart = idStart;
        }

        public Integer getN() {
            return N;
        }

        public void setN(Integer n) {
            N = n;
        }

        public Integer getM() {
            return M;
        }

        public void setM(Integer m) {
            M = m;
        }


        @Override
        public String toString() {
            return "SeaGrid{" +
                    "N=" + N +
                    ", M=" + M +
                    ", idStart=" + idStart +
                    '}';
        }
    }


    static class IntPair {
        // Ideally, name the class after whatever you're actually using
        // the int pairs *for.*
        int x;
        int y;
        int id;
        IntPair(int x, int y, int id) {this.x=x;this.y=y;this.id=id;}

        @Override
        public String toString() {
            return "IntPair{" +
                    "x=" + x +
                    ", y=" + y +
                    ", id=" + id +
                    '}';
        }
        // depending on your use case, equals? hashCode?  More methods?
    }

    static Integer getMinimumDistances(SeaGrid seaGrid) {
        var totalSize = seaGrid.getTotalSize();
        Integer distances[] = new Integer[totalSize];
        Boolean visited[] = new Boolean[totalSize];
        Queue<IntPair> queue = new LinkedList<>();

        Arrays.fill(visited, false);
        Arrays.fill(distances, Integer.MAX_VALUE);

        Integer src = seaGrid.idStart;
        visited[src] = true;
        distances[src] = 0;
        queue.add(new IntPair(seaGrid.getIdxColumnStart(), seaGrid.getIdxRowStart(), src));

        Integer extendedM = seaGrid.extendedM;
        Integer extendedN = seaGrid.extendedN;
        Integer firstDown = (seaGrid.extendedN - 1) * extendedM;

        //System.out.println(src);
        //System.out.println(seaGrid.adj[seaGrid.getIdxRowStart()].charAt(seaGrid.getIdxColumnStart()));

        while(!queue.isEmpty()) {
            IntPair crtElem = queue.remove();
            Integer crtRow = crtElem.y;
            Integer crtColumn = crtElem.x;
            Integer crtId = crtElem.id;

            //System.out.println(crtId);
            List<IntPair> neighbors = new ArrayList<>();
            char crtChar = seaGrid.adj[crtRow].charAt(crtColumn);
            if(crtChar == '.') continue;
            else if (crtChar == 'V') {
                neighbors.add(new IntPair(crtColumn, crtRow - 1, crtId - seaGrid.extendedM));
                neighbors.add(new IntPair(crtColumn, crtRow + 1, crtId + seaGrid.extendedM));
            } else if (crtChar == 'O') {
                neighbors.add(new IntPair(crtColumn - 1, crtRow, crtId - 1));
                neighbors.add(new IntPair(crtColumn + 1, crtRow, crtId + 1));
            } else if (crtChar == 'D') {
                neighbors.add(new IntPair(crtColumn, crtRow - 1, crtId - seaGrid.extendedM));
                neighbors.add(new IntPair(crtColumn, crtRow + 1, crtId + seaGrid.extendedM));
                neighbors.add(new IntPair(crtColumn - 1, crtRow, crtId - 1));
                neighbors.add(new IntPair(crtColumn + 1, crtRow, crtId + 1));
            }

//            System.out.println(neighbors);
            for (int crtSuccIt = 0; crtSuccIt < neighbors.size(); crtSuccIt++) {
                IntPair crtSucc = neighbors.get(crtSuccIt);
                // if not visited
                Integer crtSuccId = crtSucc.id;
                if (!visited[crtSuccId]) {
                    visited[crtSuccId] = true;
                    distances[crtSuccId] = distances[crtId] + 1;
                    if(seaGrid.adj[crtSucc.y].charAt(crtSucc.x) == '_') {
                        return distances[crtSuccId];
                    }
                    queue.add(crtSucc);
                }
            }
        }

        return -1;
    }

    static Integer calculateMinimumDistance(SeaGrid seaGrid, Integer distances[]) {
        int noLines = seaGrid.getExtendedN();
        int noColumns = seaGrid.getExtendedM();


        Integer minimumDstDistance = Integer.MAX_VALUE;

        for (int i = 0; i < noLines; i++) {
            minimumDstDistance = Utils.minIntegerValue(minimumDstDistance, distances[seaGrid.getCorrespondingIdX( i, 0)]);
            minimumDstDistance = Utils.minIntegerValue(minimumDstDistance, distances[seaGrid.getCorrespondingIdX( i, noColumns - 1)]);
        }

        for (int j = 1; j < noColumns; j++) {
            minimumDstDistance = Utils.minIntegerValue(minimumDstDistance, distances[seaGrid.getCorrespondingIdX( 0, j)]);
            minimumDstDistance = Utils.minIntegerValue(minimumDstDistance, distances[seaGrid.getCorrespondingIdX( noLines - 1, j)]);
        }

        if (minimumDstDistance == Integer.MAX_VALUE) minimumDstDistance = -1;
        return minimumDstDistance;
    }

    

    public static SeaGrid lastCreate() {
        MyScanner scanner = new MyScanner();

        Integer N = scanner.nextInt();
        Integer M = scanner.nextInt();

        var seaGrid = new SeaGrid(N, M);

        Integer startPosY = scanner.nextInt();
        Integer startPosX = scanner.nextInt();

        seaGrid.setIdxRowStart(startPosY);
        seaGrid.setIdxColumnStart(startPosX);

        seaGrid.setIdStart(seaGrid.
                getCorrespondingIdX(startPosY, startPosX));

        String line;

        String[] seaGridRepr = seaGrid.getAdj();
        // "_" represents land
        seaGridRepr[0] = ("_".repeat(seaGrid.M + 1));
        //while(scanner.nextLine() != null)
        int idxRow = 1;
        while((line = scanner.nextLine()) != null) {
            seaGridRepr[idxRow] = "_" + line + "_";
            idxRow++;
        }
        seaGridRepr[seaGrid.N + 1] = ("_".repeat(seaGrid.M + 1));

        //for (int i = 0; i < seaGridRepr.length; i++) {
        //    System.out.println(seaGridRepr[i]);
        //}

        return seaGrid;
    }

    public static void main(String[] args) throws IOException {
        //long startTime = System.nanoTime();

        //SeaGrid seaGrid = createSeaGrid();
        SeaGrid seaGrid = lastCreate();

        Integer minimumDistance = getMinimumDistances(seaGrid);
        //System.out.println(minimumDistance);

       // long elapsedTime = System.nanoTime() - startTime;
        try {
            FileWriter myWriter = new FileWriter("poduri.out");
            myWriter.write(minimumDistance + "");
            //myWriter.write(1 + "");
            myWriter.close();
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        //System.out.println("Total execution time to create 1000K objects in Java in s: "
         //       + elapsedTime/1e9);
    }
}