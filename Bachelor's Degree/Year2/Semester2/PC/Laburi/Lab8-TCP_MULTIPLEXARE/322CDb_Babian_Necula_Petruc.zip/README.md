# Lab 8 - PC

## Necula Alexandru, Petruc Rares, Babian Alexandru - 322CD

Am implementat si bonusul.
