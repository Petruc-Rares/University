function [sol] = hsvHistogram(path_to_image, count_bins)

    HSVMatrix = imread(path_to_image);
    
    % MODIFICAM R, G, B de peste tot in R', G', B'
    
    HSVMatrix = double(HSVMatrix)/double(255);
    
    [nr nc] = size(HSVMatrix);
    
    R = zeros(nr, nc/3);
    G = zeros(nr, nc/3);
    B = zeros(nr, nc/3);
    R = HSVMatrix(:, :, 1);
    G = HSVMatrix(:, :, 2);
    B = HSVMatrix(:, :, 3);
       
    [nr nc] = size(HSVMatrix);
    
    maxMatrix = zeros(nr, nc/3);
    minMatrix = zeros(nr, nc/3);
    deltaMatrix = zeros(nr, nc/3);
    
    maxMatrix = max(HSVMatrix(:, :, 1), HSVMatrix(:, :, 2));
    maxMatrix = max(maxMatrix, HSVMatrix(:, :, 3));
    
    minMatrix = min(HSVMatrix(:, :, 1), HSVMatrix(:, :, 2));
    minMatrix = min(minMatrix, HSVMatrix(:, :, 3));
    
    deltaMatrix = maxMatrix-minMatrix;
   
    H = zeros(nr, nc/3);
    S = zeros(nr, nc/3);
    V = zeros(nr, nc/3);
    
    % aici calculez V
    
    V = maxMatrix;

    % aici calculez S
    
    index = (maxMatrix ~= 0);
    S(index) = deltaMatrix(index)./maxMatrix(index);
    
    zeroMatrix = zeros(nr, nc/3);
    
    % aici calculez H
    
    index = ((maxMatrix == HSVMatrix(:, :, 1)) & (deltaMatrix ~= zeroMatrix));

        H(index) = 60*mod((G(index) - B(index))./deltaMatrix(index), 6);
    
    index = ((maxMatrix == G) & (deltaMatrix ~= zeroMatrix));
    
        H(index) = 60*((B(index)-R(index))./deltaMatrix(index) + 2);

    index = ((maxMatrix == B) & (deltaMatrix ~= zeroMatrix));
    
       H(index) = 60*((R(index) - G(index))./deltaMatrix(index) + 4);
    
    H = H/360;
    
    binranges = [0:1.01/count_bins:1.01]; 
    
    sol = histc(H(:), binranges)'(1:count_bins);
    sol = [sol, histc(S(:), binranges)'(1:count_bins)];
    sol = [sol, histc(V(:), binranges)'(1:count_bins)];       
  
endfunction