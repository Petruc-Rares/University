
function [Q, R] = Householder(A)
    nl = size(A)(1);
    nc = size(A)(2);
    Q = eye(nl, nl);

    nb = nrPivoti(nl, nc);

    for j = 1:nb
    
        v = zeros(nl, 1);
        H = eye(nl, nl);
        
        simbol = sign(A(j, j))*norm(A(j:nl,j));
        v(j, 1) = A(j, j) + simbol;
        
        v([j+1:nl], 1) = A([j+1:nl], j);
        
        chestie = 2 * v * v' /(v'*v);
        H = H - chestie;
        Q = Q * H';
        A = construieste(A, H, j);
        
    endfor
    
    R = A;
    
endfunction

function [x] = nrPivoti(nl, nc)
    if (nl <= nc)
        x = nl - 1;
    else
        x = nc;
    endif
endfunction

% am facut toata functia asta in loc sa inmultesc efectiv H cu A pentru ca
% operatiile de inmultire realizate asupra elementelor corespunzatoare
% de sub pivot se efectueaza degeaba(noi stim deja ca valorile de sub pivot sunt 0)
% iar in cazul matricilor mari am economisi timp prin apelarea acestei functii
function [x] = construieste(A, H, j)
    nl = size(A)(1);
    nc = size(A)(2);
    auxA = zeros(nl, nc);
    auxA = A;
    x = zeros(nl);
    % tot  ce e dupa coloana j in matricea A se calculeaza
    
    A(:, [j+1:nc]) = H * auxA(:, [j+1:nc]);
    
    %tot ce deasupra la pivot (sau pivotul) se calculeaza

    A([1:j], j) = H([1:j], :) * auxA(:, j);
    
    % tot ce e sub pivot este egal cu 0
    A(j+1:nl, j) = 0;
    
    x = A;
endfunction
