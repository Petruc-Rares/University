function [cost] = compute_cost_pc(points, centroids)
endfunction

