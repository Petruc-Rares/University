function [Q, R] = Householder(A)
endfunction