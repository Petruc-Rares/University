function [X, y] = preprocess(path_to_dataset, histogram, count_bins)
endfunction
