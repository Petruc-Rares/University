function [x] = SST(A, b)
end
    