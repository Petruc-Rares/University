%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 1, 16)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 2, 16)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 3, 16)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 4, 16)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 5, 16)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 6, 20)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 7, 20)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 8, 20)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 9, 20)

%!test
%! helper_check_hsv('ref/input/', 'ref/hsv/', 10, 20)