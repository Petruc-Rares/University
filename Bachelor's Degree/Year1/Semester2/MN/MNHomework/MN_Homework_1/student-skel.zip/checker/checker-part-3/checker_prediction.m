%!test
%! helper_check_prediction('RGB', 16);

%!test
%! helper_check_prediction('HSV', 16);

%!test
%! helper_check_prediction('RGB', 20);

%!test
%! helper_check_prediction('HSV', 20);