%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 1, 16)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 2, 16)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 3, 16)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 4, 16)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 5, 16)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 6, 20)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 7, 20)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 8, 20)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 9, 20)

%!test
%! helper_check_rgb('ref/input/', 'ref/rgb/', 10, 20)