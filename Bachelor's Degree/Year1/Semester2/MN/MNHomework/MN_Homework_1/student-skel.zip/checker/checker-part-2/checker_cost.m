%!test
%!  cost_out = compute_cost("in/test-part2-1.param", "in/test-part2-1.points");
%!  load("refs/test-part2-1.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-2.param", "in/test-part2-2.points");
%!  load("refs/test-part2-2.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-3.param", "in/test-part2-3.points");
%!  load("refs/test-part2-3.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-4.param", "in/test-part2-4.points");
%!  load("refs/test-part2-4.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-5.param", "in/test-part2-5.points");
%!  load("refs/test-part2-5.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-6.param", "in/test-part2-6.points");
%!  load("refs/test-part2-6.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-7.param", "in/test-part2-7.points");
%!  load("refs/test-part2-7.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-8.param", "in/test-part2-8.points");
%!  load("refs/test-part2-8.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-9.param", "in/test-part2-9.points");
%!  load("refs/test-part2-9.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-10.param", "in/test-part2-10.points");
%!  load("refs/test-part2-10.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-11.param", "in/test-part2-11.points");
%!  load("refs/test-part2-11.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);

%!test
%!  cost_out = compute_cost("in/test-part2-12.param", "in/test-part2-12.points");
%!  load("refs/test-part2-12.ref");
%!  assert(abs(cost_out - cost) <= 1e-5);