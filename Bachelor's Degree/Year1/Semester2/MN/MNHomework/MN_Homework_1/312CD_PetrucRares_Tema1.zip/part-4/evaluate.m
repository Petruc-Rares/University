function [percentage] = evaluate(path_to_testset, w, histogram, count_bins)
    
    in_cats = getImgs(path_to_testset, 'cats/');
    
    no_in_cats = size(in_cats)(1);
    
    in_no_cats = getImgs(path_to_testset, 'not_cats/');
    
    no_in_no_cats = size(in_no_cats)(1);
    
    favcases = 0;
    
    matrixtoscale = [];
    
    if (strcmp(histogram, "RGB") == 1)
    
        for i = 1:no_in_cats

            test_x = rgbHistogram(in_cats(i, :), count_bins);
            matrixtoscale = [matrixtoscale; test_x];

        endfor

        for i = 1:no_in_no_cats

            test_x = rgbHistogram(in_no_cats(i, :), count_bins);
            matrixtoscale = [matrixtoscale; test_x];

        endfor

        else 
            for i = 1:no_in_cats

            test_x = hsvHistogram(in_cats(i, :), count_bins);
            matrixtoscale = [matrixtoscale; test_x];

        endfor

        for i = 1:no_in_no_cats

            test_x = hsvHistogram(in_no_cats(i, :), count_bins);
            matrixtoscale = [matrixtoscale; test_x];

        endfor
    
    endif
 
    matrixtoscale = matrixtoscale - mean(matrixtoscale);
    
    matrixtoscale = matrixtoscale./std(matrixtoscale);
    
    b = zeros(size(matrixtoscale)(1), 1);
    b(1:size(matrixtoscale)(1)) = 1;
    
    matrixtoscale = [matrixtoscale, b];
    
    no_cats = no_in_cats + no_in_no_cats;
 
    array = matrixtoscale * w;
    
    array_with_cats = array(1:no_in_cats);
    favcases = size(array_with_cats(array_with_cats>=0))(1);
    
    array_without_cats = array(no_in_cats+1:no_cats);
    favcases = favcases + size(array_without_cats(array_without_cats < 0))(1);

    percentage = favcases/(no_cats);

endfunction