function [in_cats] = getImgs(path_to_dataset, ending)

    path_to_imgs = strcat(path_to_dataset, ending);
    
    img_files = dir(path_to_imgs);
    
    % numarul de imagini
        
	n = length(img_files);
	
	% lungimea numelui unui fisier
    
	D = 1:10;
    
	imgs(1:n, D) = 0;

	for i = 1:n
    
		l = 1:length(img_files(i).name);
		imgs(i, l) = img_files(i).name;
        
	end

	imgs = char(imgs);
    
    imgs = imgs(3:n-1, D);

    in_cats = strcat(path_to_imgs, imgs);

endfunction