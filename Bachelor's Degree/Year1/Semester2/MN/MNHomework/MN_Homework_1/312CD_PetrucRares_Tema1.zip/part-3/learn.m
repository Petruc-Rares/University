function [w] = learn(X, y)
   
    bias_column = zeros(size(y)(1), 1);
    w = zeros(size(X)(2) + 1, 1);
    
    bias_column(:) = 1;
    X_tilda = [X, bias_column];

    
    A = (X_tilda' * X_tilda);
    b = (X_tilda' * y);
    
    
    [Q R] = Householder(A);
    w = SST(R, Q' * b);
    
end
