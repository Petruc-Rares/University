#ifndef TREE_H_D
#define TREE_H_
#define MAX(x,y) ((x>y)?x:y)

#include <stdio.h>
#include <stdlib.h>

typedef int Item;

typedef struct Link
  {
    Item  elem;
    struct Link *l;
    struct Link *r;
  } TreeNode;



void Init(TreeNode **t, Item x)
{
	// MOD 1
	/*TreeNode*p = (TreeNode*)malloc(sizeof(TreeNode));
	p->elem = x;
	p->l = NULL;
	p->r = NULL;
	(*t) = p;*/

	// MOD 2
    (*t) = (TreeNode*)malloc(sizeof(TreeNode));
    if ((*t) == NULL) {
       	printf("Nu s-a putut aloca memorie pentru nodul cu valoare %d, \n", x);
       	exit(1);
    }
    (*t)->elem = x;
    (*t)->l = NULL;
    (*t)->r = NULL;
    return;
}

// implementare laborator
/*void Insert(TreeNode**t, Item x) {
	if ((*t) == NULL) {
		Init(t, x);
		return ;
	} else {
		if (x <= (*t)->elem)
			Insert(&((*t)->l), x);
		else
			Insert(&((*t)->r), x);
	}
}
*/

// implemenetare personala
void Insert(TreeNode **t, Item x)
{
	// daca arborele este vid initialziam radacina
	if ((*t) == NULL){
		Init(t, x);
		return ;
	}
	TreeNode* newNode;
	Init(&newNode, x);
	// se va parcurge arborele cu un pointer p
	TreeNode* p = NULL;
	// verifica daca elementul a iesit din while pe un subarbore
	// stang sau unul drept cu ajutorul indicatorului ok
	// ok = 1 daca apartine arborelui drept
	// ok = 0 daca apartine arborelui stang
	int ok = -1; 
	p = *t;
	while ((p->elem < newNode->elem) || (p->elem > newNode->elem)) {
		// daca elementul nou introdus are valoarea mai mare decat
		// a nodului curent se va merge pe ramura dreapta a nodului
		// curent
		if (p->elem < newNode->elem) {
			// daca (*t)->elem e cel mai mare element din arbore
			// se va ajunge in capatul din dreapta
			ok = 1; 
			if (p->r == NULL) {
				break;
			}
			p = p->r;
		}		
		// daca elementul nou introdus are valoarea mai mica decat
		// a nodului curent se va merge pe ramura stanga a nodului
		// curent 
		else {
			// daca (*t)->elem e cel mai mic element din arbore
			// se va ajunge in capatul din stanga
			ok = 0;
			if (p->l == NULL) {
				break;
			}
			p = p->l;
		}
	}
	if (ok == 1) {
		p->r = newNode;
	} else if (ok == 0) {
		p->l = newNode;
	}
}

void vizit(TreeNode* t) {
	printf(" %d", t->elem);
}

void PrintPostorder(TreeNode *t)
{
	if (t == NULL) return;
	PrintPostorder(t->l);
	PrintPostorder(t->r);
	vizit(t);
}

void PrintPreorder(TreeNode *t)
{
	if(t == NULL) return;
	vizit(t);
	PrintPreorder(t->l);
	PrintPreorder(t->r);
}

void PrintInorder(TreeNode *t)
{
	if (t== NULL) return;
	PrintInorder(t->l);
	vizit(t);
	PrintInorder(t->r);
}

void vizit_(TreeNode* t) {
	free(t);
}

void Free(TreeNode **t)
{	
	if ((*t) == NULL) return;
	Free(&((*t)->l));
	Free(&((*t)->r));
	vizit_(*t);
}

// implemenetare laborator
// return Size(t->l) + 1 + Size(t->r)

// implementare personala
int Size(TreeNode* t)
{
	if (t == NULL) return 0;
	// radacina este primul nod
	int count = 1;
	count += Size(t->l);
	count += Size(t->r);
	return count;
}

// la laborator similar cu size-ul, in rest e la fel
// ca ce ai facut

int maxDepth(TreeNode *t)
{
	if (t == NULL) return 0;
	int count = 1;
	int countr = 0;
	int countl = 0;
	countr += maxDepth(t->r);
	countl += maxDepth(t->l);
	count += MAX(countl, countr);
	return count;
}

#endif // LINKEDSTACK_H_INCLUDED
